

<?php $__env->startSection('content'); ?>
<style>
    body {
        background-color: #f0f2f5;
    }
</style>

<?php echo $__env->make('shared.toasts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="lg:flex max-w-5xl min-h-screen mx-auto p-6 py-10">
    <div class="flex flex-col items-center lg: lg:flex-row lg:space-x-10">

        <div class="lg:mb-12 flex-1 lg:text-left text-center">
            <img src="<?php echo e(asset( env('LOGO_SRC') )); ?>" alt="" class="lg:mx-0 lg:w-52 mx-auto w-40">
            <p class="font-medium lg:mx-0 md:text-2xl mt-6 mx-auto sm:w-3/4 text-xl"> Conéctate con amigos y el mundo que te rodea en Socialite.</p>
        </div>
        <div class="lg:mt-0 lg:w-96 md:w-1/2 sm:w-2/3 mt-10 w-full">
            <form class="p-6 space-y-4 relative bg-white shadow-lg rounded-lg" method="POST" action="<?php echo e(url('login')); ?>">
                <?php echo csrf_field(); ?>
                <input type="email" placeholder="Correo electrónico" name="email" class="with-border">
                <input type="password" placeholder="Contraseña" name="password" class="with-border">
                <button type="submit" class="bg-blue-600 font-semibold p-3 rounded-md text-center text-white w-full">
                    Iniciar Sesión
                </button>
                <a href="#" class="text-blue-500 text-center block"> ¿Has olvidado tu contraseña? </a>
                <hr class="pb-3.5">
                <div class="flex">
                    <a href="#register" type="submit" class="bg-green-600 hover:bg-green-500 hover:text-white font-semibold py-3 px-5 rounded-md text-center text-white mx-auto" uk-toggle>
                        Crear una nueva cuenta
                    </a>
                </div>
            </form>

        </div>

    </div>
</div>

<!-- This is the modal -->
<div id="register" uk-modal>
    <div class="uk-modal-dialog uk-modal-body rounded-xl shadow-2xl p-0 lg:w-5/12">
        <button class="uk-modal-close-default p-3 bg-gray-100 rounded-full m-3" type="button" uk-close></button>
        <div class="border-b px-7 py-5">
            <div class="lg:text-2xl text-xl font-semibold mb-1"> Sign Up</div>
            <div class="text-base text-gray-600"> It’s quick and easy.</div>
        </div>
        <form class="p-7 space-y-5" method="POST" action="<?php echo e(url('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="grid lg:grid-cols-2 gap-5">
                <input type="text" placeholder="Your Name" name="name" class="with-border">
                <input type="text" placeholder="Last  Name" name="surname" class="with-border">
            </div>

            <input type="text" placeholder="Your nickname" name="nick" class="with-border">
            <input type="email" placeholder="Info@example.com" name="email" class="with-border">
            <input type="password" placeholder="******" name="password" class="with-border">

            <div class="grid lg:grid-cols-2 gap-3">
                <div>
                    <label class="mb-0"> Gender </label>
                    <select class="selectpicker mt-2 with-border" name="gender">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>

                </div>
                <div>
                    <label class="mb-2"> Phone: optional </label>
                    <input type="text" placeholder="+543 5445 0543" name="phone" class="with-border">
                </div>
            </div>
            <p class="text-xs text-gray-400 pt-3">By clicking Sign Up, you agree to our
                <a href="#" class="text-blue-500">Terms</a>,
                <a href="#">Data Policy</a> and
                <a href="#">Cookies Policy</a>.
                You may receive SMS Notifications from us and can opt out any time.
            </p>
            <div class="flex">
                <button type="submit" class="bg-blue-600 font-semibold mx-auto px-10 py-3 rounded-md text-center text-white">
                    Get Started
                </button>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\aftech\social-network\social-network\resources\views/users/auth.blade.php ENDPATH**/ ?>
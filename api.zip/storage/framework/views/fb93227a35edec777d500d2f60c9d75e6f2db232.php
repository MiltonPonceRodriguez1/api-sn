

<?php $__env->startSection('content'); ?>
<div id="wrapper">

    <!-- Header -->
    <?php echo $__env->make('shared.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- sidebar -->
    <?php echo $__env->make('shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main Contents -->
    <div class="main_content">
        <div class="bg-gradient-to-tr flex from-blue-400 h-52 items-center justify-center lg:h-80 pb-10 relative to-blue-300 via-blue-400 w-full">

            <div class="text-center max-w-xl mx-auto z-10 relative px-5">
                <div class="lg:text-4xl text-2xl text-white font-semibold mb-3"> Pro Packages </div>
                <div class="text-white text-lg font-medium text-opacity-90"> ¡Elige el plan que más te convenga! Más funciones estarán disponibles gracias a los planes individuales. </div>
            </div>

        </div>
        <div class="max-w-5xl mx-auto p-7">

            <div class="-mt-16 bg-white p-10 relative rounded-md shadow">

                <div class="text-center text-xl font-semibold"> Selecciona tu plan </div>

                <!-- alerts -->
                <?php echo $__env->make('shared.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Pricing cards -->
                <div class="grid md:grid-cols-3 gap-7 mt-8">
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="<?php echo e(route('plans.subscribe', ['id' => $plan->id])); ?>">
                            <!-- Card 1 -->
                            <div class="bg-white border border-gray-100 hover:shadow-md p-6 rounded-xl">

                                <div class="font-bold mb-4 text-2xl text-black"> <?php echo e($plan->name); ?> </div>
                                <div class="font-medium mb-6 text-gray-400 text-base"> <?php echo e($plan->description); ?> </div>

                                <div class="border-b-2 border-blue-50 flex items-baseline mb-10 pb-8 space-x-2">
                                    <div class="font-semibold text-4xl text-black">$<?php echo e($plan->price); ?></div>
                                    <div class="font-medium text-gray-400">/Semana</div>
                                </div>

                                
                                <div class="space-y-4 text- font-medium text-gray-400">
                                    <?php $__currentLoopData = $plan->benefits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="flex items-center space-x-5">
                                            <i class="icon-feather-check font-bold text-blue-600"></i>
                                            <div> <?php echo e($benefit); ?> </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <button type="submit" class="bg-blue-50 mt-8 py-3 rounded-md text-blue-500 w-full font-semibold">SUSCRÍBETE AHORA</button>

                            </div>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\aftech\social-network\resources\views/plans/index.blade.php ENDPATH**/ ?>